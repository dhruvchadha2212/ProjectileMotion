﻿using UnityEngine;

public class CameraController : MonoBehaviour
{
    [SerializeField] private Rigidbody ball;
    public static Vector3 currentOffset, currentAngle;
    private CameraMovement currentCameraMovement;
    private enum CameraMovement { horizontal, vertical, withBall }
    public static readonly Vector3 frontCamOffset = new Vector3(0, 1, -4);
    public static readonly Vector3 frontCamAngle = new Vector3(0, 0, 0);
    public static readonly Vector3 coolCamOffset = new Vector3(-3, 0.5f, -1);
    public static readonly Vector3 coolCamAngle = new Vector3(0, 80, 0);
    void Start()
    {
        currentOffset = frontCamOffset;
        currentAngle = frontCamAngle;
        transform.position = ball.position + currentOffset;
        transform.eulerAngles = currentAngle;
        currentCameraMovement = CameraMovement.withBall;
    }

    void Update()
    {
        if(currentCameraMovement == CameraMovement.horizontal)
        {
            Vector3 horizontalModifier = new Vector3(-transform.position.x + ball.position.x + currentOffset.x, 0, 0);
            transform.position += horizontalModifier;
        }
        if (currentCameraMovement == CameraMovement.vertical)
        {
            Vector3 verticalModifier = new Vector3(0, -transform.position.y + ball.position.y + currentOffset.y, 0);
            transform.position += verticalModifier;
        }
        if (currentCameraMovement == CameraMovement.withBall)
        {
            transform.position = ball.position + currentOffset;
        }
    }

    public void EnterCoolCamView() //changes camera transform and angles and sets current transform and angle
    {
        transform.position = ball.position + coolCamOffset;
        transform.eulerAngles = coolCamAngle;
        currentOffset = coolCamOffset;
        currentAngle = coolCamAngle;
    }

    public void EnterFrontCamView() //changes camera transform and angles and sets current transform and angle
    {
        transform.position = ball.position + frontCamOffset;
        transform.eulerAngles = frontCamAngle;
        currentOffset = frontCamOffset;
        currentAngle = frontCamAngle;
    }

    public void SetCameraMovementHorizontal()
    {
        currentCameraMovement = CameraMovement.horizontal;
    }

    public void SetCameraMovementVertical()
    {
        currentCameraMovement = CameraMovement.vertical;
    }

    public void SetCameraMovementWithBall()
    {
        currentCameraMovement = CameraMovement.withBall;
    }
}
